//
//  main.m
//  Obje-COreally
//
//  Created by Akash Soni on 18/04/19.
//  Copyright © 2019 Akash Soni. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
