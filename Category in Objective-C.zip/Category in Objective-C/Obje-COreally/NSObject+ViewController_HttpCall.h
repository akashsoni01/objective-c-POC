//
//  NSObject+ViewController_HttpCall.h
//  Obje-COreally
//
//  Created by Akash Soni on 21/04/19.
//  Copyright © 2019 Akash Soni. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ViewController (ViewController_HttpCall)
    -(void)printCounter:(int) arg1 arg2Msg:(NSString*)name;
@end

NS_ASSUME_NONNULL_END
